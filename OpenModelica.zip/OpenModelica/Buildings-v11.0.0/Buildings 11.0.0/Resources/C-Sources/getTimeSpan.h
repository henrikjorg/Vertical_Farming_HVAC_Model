/*
 * getTimeSpan.h
 *
 *  Created on: Apr 16, 2019
 *      Author: jianjun
 */

#ifndef GETTIMESPAN_H_
#define GETTIMESPAN_H_

void getTimeSpan(const char * fileName, const char * tabName, double* timeSpan);

#endif /* GETTIMESPAN_H_ */
