import re
import glob
import shutil
from pathlib import Path
from collections import defaultdict

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ─────────────────────────────────────────────────────────────────────────
# Increase default plot font sizes (won't affect table cell fonts)
plt.rcParams.update({
    "axes.titlesize": 18,
    "axes.labelsize": 16,
    "xtick.labelsize": 14,
    "ytick.labelsize": 14,
    "legend.fontsize": 12,
    "legend.title_fontsize": 14,
    "axes.formatter.useoffset": False
})

# Directories
CSV_DIR  = Path("OpenModelica/CSV_files")
TEMP_DIR = Path("OpenModelica/Temporary_information")
PLOT_DIR = Path("OpenModelica/plot_storage")
TXT_DIR  = Path("OpenModelica/txt_files")

# Ensure directories exist
TEMP_DIR.mkdir(exist_ok=True, parents=True)
PLOT_DIR.mkdir(exist_ok=True, parents=True)
TXT_DIR.mkdir(exist_ok=True)

# Parameters
PATTERN = str(CSV_DIR / "Full_range_test_*gs_*W_*degC.csv")
T_PERIOD        = 30_000
T_SAMPLE_OFFSET = 29_999
TEMPS           = list(range(15, 31))
RH_SET          = [0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85]
T_TOL, RH_TOL   = 0.05, 0.01


def build_array(df):
    """Extract one sample per T_PERIOD interval and pivot to a T×RH table of cooler temps."""
    sample_t = np.arange(T_SAMPLE_OFFSET, df.time.max() + 1, T_PERIOD)
    rec = []
    for t in sample_t:
        row = df[df.time <= t].iloc[-1]
        rec.append({
            "t_set":  int(round(row["Temp_Distributer.y"])),
            "rh_set": round(row["RH_Distributer.y"], 2),
            "cool":   row["Temp_cooler_output.T"],
            "ret_t":  row["Temp_return_air.T"],
            "ret_rh": row["RH_return_air.phi"],
        })
    sam = pd.DataFrame(rec).drop_duplicates(["t_set", "rh_set"], keep="last")
    good = (
        sam.ret_t.sub(sam.t_set).abs() < T_TOL
    ) & (
        sam.ret_rh.sub(sam.rh_set).abs() < RH_TOL
    )
    tbl = (
        sam.pivot_table("cool", "t_set", "rh_set", aggfunc="first")
           .reindex(index=TEMPS, columns=RH_SET)
    )
    mask = (
        sam.assign(green=good)
           .pivot_table("green", "t_set", "rh_set", aggfunc="first", fill_value=False)
           .reindex(index=TEMPS, columns=RH_SET, fill_value=False)
    )
    return tbl.where(mask).to_numpy()


def smart_fill(raw: np.ndarray):
    df = pd.DataFrame(raw, index=TEMPS, columns=RH_SET)
    mask_ext = np.zeros_like(raw, dtype=bool)
    mask_interp = np.zeros_like(raw, dtype=bool)

    # 1) extrapolate per-column in T
    for j, rh in enumerate(RH_SET):
        ser = df[rh].dropna()
        if len(ser) < 2:
            continue

        # below lowest measured
        t0, t1 = ser.index[0], ser.index[1]
        m_low = (ser.iloc[1] - ser.iloc[0]) / (t1 - t0)
        for T in [x for x in TEMPS if x < t0]:
            df.at[T, rh] = ser.iloc[0] + m_low * (T - t0)
            mask_ext[TEMPS.index(T), j] = True

        # above highest measured
        ta, tb = ser.index[-2], ser.index[-1]
        m_hi = (ser.iloc[-1] - ser.iloc[-2]) / (tb - ta)
        for T in [x for x in TEMPS if x > tb]:
            df.at[T, rh] = ser.iloc[-1] + m_hi * (T - tb)
            mask_ext[TEMPS.index(T), j] = True

    # 2) interpolate row-wise across RH
    filled = df.to_numpy()
    xs = np.array(RH_SET)
    for i, T in enumerate(TEMPS):
        row = filled[i, :].copy()
        ok = ~np.isnan(row)
        if ok.sum() >= 2:
            new = np.interp(xs, xs[ok], row[ok])
            mask_interp[i, :] = np.isnan(raw[i, :]) & ~np.isnan(new)
            filled[i, :] = new

    return filled, mask_ext, mask_interp


def colour_table(ax, colours: np.ndarray, values: np.ndarray, rowLabels, colLabels, fontsize=11, value_fmt="{:.1f}"):
    """
    Draw a table of cells colored according to `colours`, with `values` shown formatted,
    and the given row and column labels. Fixed row height of 1.2.
    """
    n_rows, n_cols = colours.shape
    # initialize cell_text with empty strings
    cell_text = [["" for _ in range(n_cols)] for _ in range(n_rows)]
    for i in range(n_rows):
        for j in range(n_cols):
            if not np.isnan(values[i, j]):
                cell_text[i][j] = value_fmt.format(values[i, j])

    tbl = ax.table(
        cellText    = cell_text,
        cellColours = colours,
        rowLabels   = rowLabels,
        colLabels   = colLabels,
        cellLoc     = 'center',
        loc         = 'upper left'
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(fontsize)
    tbl.scale(1, 1.5)  # increased row height
    for cell in tbl.get_celld().values():
        cell.set_linewidth(0.5)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(left=False, labelleft=False, bottom=False, labelbottom=False)
    return tbl


def save_table_png(tbl, fig, ax, path: Path,
                   xlabel: str = None, ylabel: str = None,
                   pad: float = 0.02,
                   label_fontsize: float = 11):
    """
    Resize the figure to fit the table bbox, add optional axis labels,
    adjust column widths (auto +0.2), and save.
    """
    if xlabel:
        ax.set_xlabel(xlabel, fontsize=label_fontsize)
        ax.xaxis.set_label_position('top')
        ax.xaxis.set_label_coords(0.5, 1.02)
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=label_fontsize)
        ax.yaxis.set_label_position('left')
        ax.yaxis.set_label_coords(-0.1, 0.5)

    cols = sorted({col for (_, col) in tbl.get_celld().keys() if col >= 0})
    tbl.auto_set_column_width(col=cols)
    for (r, c), cell in tbl.get_celld().items():
        if c >= 0:
            cell.set_width(cell.get_width() + 0.4)

    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bbox = tbl.get_window_extent(renderer).transformed(fig.dpi_scale_trans.inverted())

    artists = [tbl]
    if xlabel:
        artists.append(ax.xaxis.label)
    if ylabel:
        artists.append(ax.yaxis.label)

    fig.set_size_inches(bbox.width, bbox.height)
    fig.savefig(path, dpi=300, bbox_inches='tight', pad_inches=pad, bbox_extra_artists=artists)
    plt.close(fig)


def save_and_plot(raw: np.ndarray, tag: str) -> np.ndarray:
    mask_raw = ~np.isnan(raw)
    filled, mask_ext, mask_interp = smart_fill(raw.copy())
    mask_ext    &= ~mask_raw
    mask_interp &= ~mask_raw

    # Save numpy and CSVs
    np.save(TEMP_DIR / f"{tag}_raw.npy", raw)
    np.save(TEMP_DIR / f"{tag}_filled.npy", filled)
    pd.DataFrame(raw,    index=TEMPS, columns=RH_SET).to_csv(
        TEMP_DIR / f"{tag}_raw.csv", float_format="%.3f"
    )
    pd.DataFrame(filled, index=TEMPS, columns=RH_SET).to_csv(
        TEMP_DIR / f"{tag}_filled.csv", float_format="%.3f"
    )

    # ── Table plot with values ──────────────────────────────────────────
    nrows, ncols = len(TEMPS), len(RH_SET)
    colours = np.full((nrows, ncols), "#ffffff", dtype=object)
    for i in range(nrows):
        for j in range(ncols):
            if mask_raw[i, j]:
                colours[i, j] = "#a1f974"
            elif mask_ext[i, j]:
                colours[i, j] = "#fdf24d"
            elif mask_interp[i, j]:
                colours[i, j] = "#fffac8"

    fig, ax = plt.subplots()
    tbl = colour_table(
        ax,
        colours,
        values=filled,
        rowLabels=[f"{t}" for t in TEMPS],
        colLabels=[f"{int(r*100)}" for r in RH_SET],
        fontsize=8,
        value_fmt="{:.1f}"
    )
    save_table_png(
        tbl, fig, ax,
        PLOT_DIR / f"{tag}_table.png",
        xlabel="RH set-point [%]",
        ylabel="Temperature set-point [°C]",
        label_fontsize=11
    )


    # ── Curves plot ─────────────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(9, 6))
    t_axis = np.array(TEMPS)
    for j, rh in enumerate(RH_SET):
        y_fill = filled[:, j]
        ok_raw = ~np.isnan(raw[:, j])
        ok_ext = mask_ext[:, j]

        if ok_raw.any():
            ax.plot(
                t_axis[ok_raw], y_fill[ok_raw],
                marker='o', linestyle='-', lw=2.5, markersize=6, color=f"C{j}",
                label=f"{int(rh*100)}% RH"
            )
        if ok_ext.any():
            ax.plot(
                t_axis[ok_ext], y_fill[ok_ext],
                marker='s', linestyle='None', markersize=6, color=f"C{j}"
            )
            low_meas  = t_axis[ok_raw].min() if ok_raw.any() else None
            high_meas = t_axis[ok_raw].max() if ok_raw.any() else None
            low_ext_mask  = ok_ext & (t_axis < (low_meas or 0))
            high_ext_mask = ok_ext & (t_axis > (high_meas or 100))

            for mask_group in (low_ext_mask, high_ext_mask):
                xs = t_axis[mask_group]
                ys = y_fill[mask_group]
                for k in range(len(xs)-1):
                    ax.plot([xs[k], xs[k+1]], [ys[k], ys[k+1]],
                            linestyle=':', lw=2.5, color=f"C{j}")

            if low_meas is not None and low_ext_mask.any():
                xs_low, ys_low = t_axis[low_ext_mask], y_fill[low_ext_mask]
                ax.plot([xs_low.max(), low_meas],
                        [ys_low.max(), y_fill[ok_raw].min()],
                        linestyle=':', lw=2.5, color=f"C{j}")
            if high_meas is not None and high_ext_mask.any():
                xs_high, ys_high = t_axis[high_ext_mask], y_fill[high_ext_mask]
                ax.plot([high_meas, xs_high.min()],
                        [y_fill[ok_raw].max(), ys_high.min()],
                        linestyle=':', lw=2.5, color=f"C{j}")

    ax.set_xlabel("Temperature set-point [°C]", fontsize=11)
    ax.set_ylabel("Cooling temperature [°C]", fontsize=11)
    ax.grid(True, linestyle='--', alpha=0.4)
    handles, labels = ax.get_legend_handles_labels()
    legend = ax.legend(handles[::-1], labels[::-1], title="Relative humidity")
    legend.get_frame().set_linewidth(0)
    fig.tight_layout()
    fig.savefig(PLOT_DIR / f"{tag}_curves.png", dpi=300)
    plt.close(fig)

    # ── Write table to text file ────────────────────────────────────────
    txt_path = TXT_DIR / f"cooling_table_{tag}.txt"
    with open(txt_path, "w") as f:
        n_rows_txt = nrows + 1
        n_cols_txt = ncols + 1
        f.write("#1\n")
        f.write(f"double table({n_cols_txt},{n_rows_txt})\n")
        temps_hdr = TEMPS
        f.write("0 " + " ".join(f"{T:.1f}" for T in temps_hdr) + "\n")
        for j, rh in enumerate(RH_SET):
            vals = filled[:, j]
            f.write(f"{rh:.2f} " + " ".join(f"{v:.4f}" for v in vals) + "\n")

    return filled


# ── main loop ─────────────────────────────────────────────────────────
fraction_groups = defaultdict(list)
file_re = re.compile(r"_test_([\d.]+)gs_(\d+)W_[\d.]+degC\.csv$")


for p in glob.glob(PATTERN):
    m = file_re.search(p)
    if not m:
        continue
    gs = m.group(1)
    fraction_groups[gs].append(p)

merged = {}
for frac, paths in fraction_groups.items():
    # sort by LED power (the (\d+)W part) ascending
    paths = sorted(
        paths,
        key=lambda p: int(re.search(r"_([\d]+)W_", p).group(1))
    )

    master = None
    for p in paths:
        arr = build_array(pd.read_csv(p))
        if master is None:
            master = arr
        else:
            # only fill in the NaNs from earlier runs
            master = np.where(np.isnan(master), arr, master)

    merged[frac] = save_and_plot(master, f"{frac}gs")


# Cleanup
print(f"⚠ removing temporary folder {TEMP_DIR}")
shutil.rmtree(TEMP_DIR, ignore_errors=True)












# 1) Rebuild merged raw, merged filled, and the extrapolation mask for each vapor‐rate
merged_raw      = {}
merged_filled   = {}
merged_mask_ext = {}

for frac, paths in fraction_groups.items():
    master_raw = None
    for p in paths:
        arr = build_array(pd.read_csv(p))
        master_raw = arr if master_raw is None else np.where(np.isnan(master_raw), arr, master_raw)
    # get both filled and mask_ext back out of smart_fill
    filled, mask_ext, _ = smart_fill(master_raw.copy())
    merged_raw[frac]      = master_raw
    merged_filled[frac]   = filled
    merged_mask_ext[frac] = mask_ext

# sort the vapor‐rates numerically
rates = sorted(merged_filled.keys(), key=lambda s: float(s))
rates = [float(r) for r in rates]


# helper to pull out a column (for a fixed RH) or row (for a fixed T)
def series_for(frac_list, data_dict, idx, axis='col'):
    y = []
    for f in frac_list:
        arr = data_dict[str(f)]
        if axis=='col':
            y.append(arr[:, idx])
        else:
            y.append(arr[idx, :])
    return np.vstack(y)  # shape = (len(frac_list), len(TEMPS) or len(RH_SET))

# 2) Three plots: fixed RH → all T-sets
for rh in (0.55, 0.75, 0.80):
    j = RH_SET.index(rh)
    fig, ax = plt.subplots(figsize=(8,5))
    for i, T in enumerate(TEMPS):
        y = [ merged_filled[str(f)][i, j] for f in rates ]
        ext = [ merged_mask_ext[str(f)][i, j] for f in rates ]
        ax.plot(rates, y, '-o', label=f"{T}°C")
        x_ext = [r for r, e in zip(rates, ext) if e]
        y_ext = [v for v, e in zip(y,   ext) if e]
        ax.scatter(x_ext, y_ext, marker='s', s=80, facecolors='none', edgecolors='k')
    ax.set_xlabel("Water‐vapor rate [g/s]")
    ax.set_ylabel("Cooling temperature [°C]")
    #ax.set_title(f"RH = {int(rh*100)}%")
    ax.grid(True, ls='--', alpha=0.4)

    handles, labels = ax.get_legend_handles_labels()
    ax.legend(
        handles[::-1], labels[::-1],
        title="Tₛₑₜ",
        loc="upper left",
        bbox_to_anchor=(1.02, 1),
        borderaxespad=0
    )
    fig.tight_layout()
    plt.subplots_adjust(right=0.75)
    fig.savefig(PLOT_DIR / f"wv_rate_vs_cool_RH{int(rh*100)}.png", dpi=300)
    plt.close(fig)

# 3) Four plots: fixed T-set → all RHs
for T in (18, 21, 24, 27):
    i = TEMPS.index(T)
    fig, ax = plt.subplots(figsize=(8,5))
    for j, rh in enumerate(RH_SET):
        y = [ merged_filled[str(f)][i, j] for f in rates ]
        ext = [ merged_mask_ext[str(f)][i, j] for f in rates ]
        ax.plot(rates, y, '-o', label=f"{int(rh*100)}% RH")
        x_ext = [r for r, e in zip(rates, ext) if e]
        y_ext = [v for v, e in zip(y,   ext) if e]
        ax.scatter(x_ext, y_ext, marker='s', s=80, facecolors='none', edgecolors='k')
    ax.set_xlabel("Water‐vapor rate [g/s]")
    ax.set_ylabel("Cooling temperature [°C]")
    ax.set_title(f"Tₛₑₜ = {T}°C")
    ax.grid(True, ls='--', alpha=0.4)

    # ← and here
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(
        handles[::-1], labels[::-1],
        title="Tₛₑₜ",
        loc="upper left",
        bbox_to_anchor=(1.02, 1),
        borderaxespad=0
    )
    fig.tight_layout()
    plt.subplots_adjust(right=0.75)
    fig.savefig(PLOT_DIR / f"wv_rate_vs_cool_T{T}.png", dpi=300)
    plt.close(fig)
