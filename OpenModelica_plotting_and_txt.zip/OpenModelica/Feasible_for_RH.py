import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

from cooling_tables import build_cooling_array, colour_table, save_table_png

# ────────── folders & config ─────────────────────────────────
CSV_DIR     = Path("OpenModelica/CSV_files")
PLOT_DIR    = Path("OpenModelica/plot_storage/full")
PLOT_DIR.mkdir(exist_ok=True, parents=True)

TEMPS       = list(range(15, 31))      # 15–30 °C
OUTS        = [18, 19, 20, 21, 22, 23]
RH_SET      = [0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85]
RH_IDX      = RH_SET.index(0.75)
GS_VALUES   = [0.001, 0.01, 0.02]
POWER_LEVELS = [0, 300]                # only 0 and 300 W

# ────────── font settings ────────────────────────────────────
plt.rcParams.update({
    'font.size':         8,
    'axes.labelsize':   12,
    'xtick.labelsize':   8,
    'ytick.labelsize':   8,
})

def make_matrix_for(gs: float, power: int):
    n_rows, n_cols = len(TEMPS), len(OUTS)
    feas = np.zeros((n_rows, n_cols), dtype=bool)

    for j, T_out in enumerate(OUTS):
        fname = f"Full_range_test_{gs}gs_{power}W_{T_out}degC.csv"
        try:
            df = pd.read_csv(CSV_DIR / fname)
            _, green = build_cooling_array(df)
            feas[:, j] = green[:, RH_IDX]
        except Exception as e:
            print(f"Warning: skipping {fname}: {e}")

    colours = np.where(feas, '#a1f974', '#ff9579')

    fig, ax = plt.subplots(figsize=(6, 6))
    tbl = colour_table(ax, colours,
                       rowLabels=[str(t) for t in TEMPS],
                       colLabels=[str(T) for T in OUTS])
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(8)
    for col in range(n_cols):
        tbl.auto_set_column_width(col=col)
    for (_, c), cell in tbl.get_celld().items():
        if c >= 0: cell.set_width(cell.get_width() + 0.2)

    ax.set_xlabel("Outer temp [°C]")
    ax.xaxis.set_label_position('top')
    ax.set_ylabel("Set-point temperature [°C]")
    ax.yaxis.set_label_position('left')
    ax.tick_params(labelsize=8)
    plt.tight_layout()

    outname = f"matrix_{n_rows}x{n_cols}_RH75_{gs}gs_{power}W.png"
    save_table_png(tbl, fig, ax, PLOT_DIR / outname)
    plt.close(fig)
    print(f"Saved {outname}")

def main():
    for power in POWER_LEVELS:
        for gs in GS_VALUES:
            if power == 300 and gs == 0.01:
                continue
            make_matrix_for(gs, power)

if __name__ == "__main__":
    main()

