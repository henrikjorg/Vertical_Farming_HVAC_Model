import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

from cooling_tables import build_cooling_array, colour_table, save_table_png

# ────────── folders & config ─────────────────────────────────
CSV_DIR      = Path("OpenModelica/CSV_files")
PLOT_DIR     = Path("OpenModelica/plot_storage")
PLOT_DIR.mkdir(exist_ok=True, parents=True)

# full set of set-point temps (16 rows)
TEMPS        = list(range(15, 31))      # 15–30 °C
# reduced set-points for 600 W (10 rows)
TEMPS_600    = list(range(21, 31))      # 21–30 °C

RH_SET       = [0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85]
RH_IDX       = RH_SET.index(0.75)

# reduced outer temps for 600 W (3 cols)
OUTS_600     = [18, 19, 20]

GS_VALUES    = [0.001, 0.01, 0.02]      # mass‐flow rates
POWER        = 600                     # fixed at 600 W only

# ────────── base font settings ────────────────────────────────
plt.rcParams.update({
    'font.size':         8,
    'axes.labelsize':   10,
    'xtick.labelsize':   8,
    'ytick.labelsize':   8,
})


def make_matrix_for(gs: float, power: int):
    """Build & save one feasibility matrix for a given gs and power level."""
    temps = TEMPS_600
    outs  = OUTS_600

    orig_idx = [TEMPS.index(t) for t in temps]
    n_rows, n_cols = len(temps), len(outs)
    feas = np.zeros((n_rows, n_cols), dtype=bool)

    for j, T_out in enumerate(outs):
        fname = f"Full_range_test_{gs}gs_{power}W_{T_out}degC.csv"
        try:
            df = pd.read_csv(CSV_DIR / fname)
            _, green = build_cooling_array(df)
            feas[:, j] = green[orig_idx, RH_IDX]
        except Exception as e:
            print(f"Warning: skipping {fname}: {e}")
            feas[:, j] = False

    # Font sizes
    cell_fontsize = 12
    label_fontsize = 12
    tick_fontsize = 10

    # Colors
    colours = np.where(feas, '#a1f974', '#ff9579')

    # Create plot + table
    width = 2.2 * n_cols + 1
    height = 0.5 * n_rows + 2
    fig, ax = plt.subplots(figsize=(width, height))

    tbl = colour_table(
        ax,
        colours,
        rowLabels=[str(t) for t in temps],
        colLabels=[str(T) for T in outs]
    )

    # Style the table
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(cell_fontsize)

    for (r, c), cell in tbl.get_celld().items():
        if c >= 0:
            cell.set_width(2)     # Wider columns
        if r >= 0:
            cell.set_height(0.067)    # Taller rows


    # Axis labels
    ax.set_xlabel("Outer temp [°C]", fontsize=label_fontsize)
    ax.xaxis.set_label_position('top')
    ax.xaxis.set_label_coords(0.3, 1.02)
    ax.set_ylabel("")  # suppress default y-label

    # manually add label further left
    fig.text(-0.15, 0.55, "Set-point temperature [°C]",
            va='center', ha='center', rotation='vertical', fontsize=label_fontsize)


    ax.tick_params(axis='both', which='major', labelsize=tick_fontsize)

    # Manual layout (replaces tight_layout)
    plt.subplots_adjust(left=0.2, right=0.95, top=0.9, bottom=0)

    # Save to file
    outname = f"matrix_{n_rows}x{n_cols}_RH75_{gs}gs_{power}W.png"
    save_table_png(
        tbl,
        fig,
        ax,
        PLOT_DIR / outname,
        xlabel="Outer temp [°C]",
        pad = 0.3
    )

    plt.close(fig)
    print(f"Saved {outname}")


def main():
    for gs in GS_VALUES:
        if gs == 0.01:
            continue
        make_matrix_for(gs, POWER)


if __name__ == "__main__":
    main()
