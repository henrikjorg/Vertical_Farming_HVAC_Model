import glob, os
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

# ───── directories ──────────────────────────────────────
CSV_DIR  = Path("OpenModelica/CSV_files")
PLOT_DIR = Path("OpenModelica/plot_storage")
PLOT_DIR.mkdir(exist_ok=True)


PATTERN = str(CSV_DIR / "Full_range_test_*gs_*W_*degC.csv")


# ───── loop over every matching CSV ─────────────────────
for csv_path in glob.glob(PATTERN):
    df  = pd.read_csv(csv_path)
    tag = Path(csv_path).stem
    t_d = df["time"] / 86_400  # seconds → days

    # ── build combined figure (2 stacked sub-plots) ────
    fig, (axT, axRH) = plt.subplots(
        nrows=2, ncols=1, sharex=True,
        figsize=(14, 10),
        height_ratios=[2, 1.6]
    )

    # ––– Temperature (top) –––
    axT.plot(
        t_d,
        df["Temp_return_air.T"],
        label="Return-air T",
        color="green",
        linewidth=2
    )
    axT.plot(
        t_d,
        df["Temp_Distributer.y"],
        label="T set-point",
        color="tab:orange",
        linestyle="--",
        linewidth=2
    )
    axT.set_ylabel("Temperature [°C]", fontsize=30)
    axT.tick_params(axis='both', labelsize=30)
    axT.grid(True)

    # ––– RH (bottom) –––
    axRH.plot(
        t_d,
        df["RH_return_air.phi"],
        label="Return-air RH",
        color="green",
        linewidth=2
    )
    axRH.plot(
        t_d,
        df["RH_Distributer.y"],
        label="RH set-point",
        color="tab:orange",
        linestyle="--",
        linewidth=2
    )
    axRH.set_xlabel("Time [days]", fontsize=30)
    axRH.set_ylabel("RH [–]", fontsize=30)
    axRH.tick_params(axis='both', labelsize=30)
    axRH.grid(True)

    # bigger legends
    axT.legend(fontsize=30)
    axRH.legend(fontsize=30)

    fig.tight_layout()

    # rename output to Plot_full_test_*W_*gs.png
    out_tag = tag.replace("Full_range_test", "Plot_full_test")
    fig.savefig(PLOT_DIR / f"{out_tag}.png", dpi=300)

    plt.close(fig)

print("✔  Combined plots written to", PLOT_DIR)
plt.waitforbuttonpress()
