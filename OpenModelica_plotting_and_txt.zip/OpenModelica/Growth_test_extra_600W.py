import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# ───── paths ─────────────────────────────────────────────
CSV_PATH = Path("OpenModelica/CSV_files/Growth_HVAC_tests/Growth_test_600W_extra.csv")
PLOT_DIR = Path("OpenModelica/plot_storage/growth_tests")
PLOT_DIR.mkdir(parents=True, exist_ok=True)

# ───── load data ─────────────────────────────────────────
df = pd.read_csv(CSV_PATH)
t_d = df["time"] / 86400  # seconds → days

# ───── create stacked subplots ───────────────────────────
fig, (axL, axV) = plt.subplots(
    nrows=2, ncols=1, sharex=True,
    figsize=(20, 10),
    height_ratios=[1, 2]
)

# ───── Light intensity (top) ─────────────────────────────
axL.plot(t_d, df["Light_intensity_W.y"], color="orange", linewidth=2, label="Light intensity")
axL.set_ylabel("Light [W]", fontsize=30, labelpad=15)
axL.set_yticks(range(0, int(df["Light_intensity_W.y"].max()) + 100, 200))
axL.tick_params(axis='both', labelsize=30)
axL.grid(True)
axL.legend(
    fontsize=30,
    loc="center left",
    bbox_to_anchor=(1.02, 0.5),
    borderaxespad=0
)

# ───── Water vapor + Transpiration (bottom) ──────────────
axV.plot(t_d, df["Total_water_vapor_rate.y"], label="Total rate of\nwater vapor", color="blue", linewidth=2)
axV.plot(t_d, df["Growth_period_plant_transpiration.y[1]"], label="Plant transpiration", color="green", linestyle="--", linewidth=2)

axV.set_xlabel("Time [days]", fontsize=30, labelpad=15)
axV.set_ylabel("Water vapor [g/s]", fontsize=30, labelpad=15)
axV.set_xlim(0, 24.01)
axV.set_xticks([0, 4, 8, 12, 16, 20, 24])
axV.tick_params(axis='both', labelsize=30)
axV.grid(True)
axV.legend(
    fontsize=30,
    loc="center left",
    bbox_to_anchor=(1.02, 0.5),
    borderaxespad=0
)

# ───── layout + export ──────────────────────────────────
fig.tight_layout()
fig.subplots_adjust(left=0.1, right=0.7)

outfile = PLOT_DIR / "Plot_growth_test_600W_transpiration_light.png"
fig.savefig(outfile, dpi=300)
plt.close(fig)

print(f"✔ Plot saved to: {outfile}")
