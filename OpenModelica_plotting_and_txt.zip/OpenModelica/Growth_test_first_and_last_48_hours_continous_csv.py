import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import numpy as np
from pathlib import Path

# ───── paths ─────────────────────────────────────────────
base_dir = Path("OpenModelica/CSV_files/Growth_HVAC_tests")
plot_dir = Path("OpenModelica/plot_storage/growth_tests")
plot_dir.mkdir(parents=True, exist_ok=True)

# ───── load full-range CSVs ─────────────────────────────
df = pd.read_csv(base_dir / "Growth_test_600W_ramp_30min.csv")
df_extra = pd.read_csv(base_dir / "Growth_test_600W_extra_ramp30_min.csv")

# ───── calculate time thresholds ────────────────────────
start_time = df["time"].min()
end_time = df["time"].max()

first_48_end = start_time + 48 * 3600
last_48_start = end_time - 48 * 3600

# ───── filter into first and last 48 hours ──────────────
df_first = df[df["time"] <= first_48_end]
df_last = df[df["time"] >= last_48_start]

df_extra_first = df_extra[df_extra["time"] <= first_48_end]
df_extra_last = df_extra[df_extra["time"] >= last_48_start]

# ───── rescale time to 0–48 h for each slice ────────────
t_first = (df_first["time"] - df_first["time"].min()) / 3600
t_last = (df_last["time"] - df_last["time"].min()) / 3600

# ───── shared y-axis limits ─────────────────────────────
y_temp_lim = [min(df["Temp_cooler_output.T"].min(), df["Temp_cooler_output.T"].min()), 26]
y_rh_lim = [0, 100]
y_x_lim = [
    min(df["senMasFra_return.X"].min(), df["senMasFra_return.X"].min()),
    max(df["senMasFra_heated.X"].max(), df["senMasFra_heated.X"].max())
]
y_light_lim = [
    0,
    int(np.ceil(df_extra["Light_intensity_W.y"].max() + 100))
]

# ───── figure setup ─────────────────────────────────────
fig, axes = plt.subplots(nrows=4, ncols=2, sharex='col', figsize=(30, 20),
                         height_ratios=[2, 1.6, 1.4, 1.2])

titles = ["First 48 Hours", "Last 48 Hours"]
ylabels = ["Temperature [°C]", "RH [%]", "Humidity Ratio [–]", "Light [W]"]
xticks = range(0, 49, 6)

# ───── plotting ─────────────────────────────────────────
for row, ylabel in enumerate(ylabels):
    for col, (df_, df_extra_, t_) in enumerate([
        (df_first, df_extra_first, t_first),
        (df_last, df_extra_last, t_last)
    ]):
        ax = axes[row][col]

        if row == 0:
            ax.plot(t_, df_["Temp_heater_output.T"], label="Supply air", color="red", linewidth=4)
            ax.plot(t_, df_["Temp_cooler_output.T"], label="Cooled air", color="blue", linewidth=4)
            ax.plot(t_, df_["Temp_return_air.T"], label="Return air", color="lime", linewidth=7,
                    path_effects=[pe.Stroke(linewidth=8.5, foreground='darkgreen'), pe.Normal()])
            ax.plot(t_, df_["Temp_Distributer.y"], label="Set-point", color="black", linestyle="--", linewidth=4)
            ax.set_ylim(y_temp_lim)

        elif row == 1:
            ax.plot(t_, df_["RH_cooler_output.phi"] * 100, label="Cooled air", color="blue", linewidth=4)
            ax.plot(t_, df_["RH_return_air.phi"] * 100, label="Return-air", color="lime", linewidth=7,
                    path_effects=[pe.Stroke(linewidth=8.5, foreground='darkgreen'), pe.Normal()])
            ax.plot(t_, df_["RH_Distributer.y"] * 100, label="Set-point", color="black", linestyle="--", linewidth=4)
            ax.set_ylim(y_rh_lim)

        elif row == 2:
            ax.plot(t_, df_["senMasFra_return.X"], label="Return-air", color="limegreen", linewidth=4)
            ax.plot(t_, df_["senMasFra_heated.X"], label="Supply-air", color="red", linewidth=4)
            ax.set_ylim(y_x_lim)

        elif row == 3:
            ax.plot(t_, df_extra_["Light_intensity_W.y"], label="Light intensity", color="orange", linewidth=4)
            ax.set_ylim(y_light_lim)
            ax.set_yticks(np.arange(y_light_lim[0], y_light_lim[1] + 1, 200))
            ax.set_xlabel("Time [hours]", fontsize=40, labelpad=20)
            ax.set_xticks(xticks)

        ax.set_xlim(0, 48.01)
        if col == 0:
            ax.set_ylabel(ylabel, fontsize=40, labelpad=20)
        if row == 0:
            ax.set_title(titles[col], fontsize=40, pad=20)

        ax.tick_params(axis='both', labelsize=30)
        ax.grid(True)

    handles, labels = axes[row][1].get_legend_handles_labels()
    axes[row][1].legend(handles, labels, fontsize=35, loc="center left", bbox_to_anchor=(1.02, 0.5))

# ───── layout and save ──────────────────────────────────
fig.tight_layout()
fig.subplots_adjust(left=0.08, right=0.8, hspace=0.45, wspace=0.16)

outfile = plot_dir / "Plot_growth_test_600W_first_and_last_48_hours_ramp_30min_test.png"
fig.savefig(outfile, dpi=300)
plt.close(fig)

print(f"✔ Plot saved to: {outfile}")
