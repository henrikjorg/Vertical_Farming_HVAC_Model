import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import numpy as np
from pathlib import Path

# ───── paths ─────────────────────────────────────────────
base_dir = Path("OpenModelica/CSV_files/Growth_HVAC_tests")
plot_dir = Path("OpenModelica/plot_storage/growth_tests")
plot_dir.mkdir(parents=True, exist_ok=True)

# ───── load data ─────────────────────────────────────────
df_full = pd.read_csv(base_dir / "Growth_test_600W_48_hours_steps.csv")
df_last = pd.read_csv(base_dir / "Growth_test_600W_last_48_hours_800_steps.csv")
df_last = df_last[df_last["time"] >= 1900800]
t_last = (df_last["time"] - df_last["time"].min()) / 3600

df_extra_last = pd.read_csv(base_dir / "Growth_test_600W_extra_last_48_hours_800_steps.csv")
df_extra_last = df_extra_last[df_extra_last["time"] >= 1900800]

df_extra_full = pd.read_csv(base_dir / "Growth_test_600W_extra_48_hours_steps.csv")

t_full = df_full["time"] / 3600
t_last = (df_last["time"] - df_last["time"].min()) / 3600

# ───── shared y-axis limits ─────────────────────────────
y_temp_lim = [min(df_full["Temp_cooler_output.T"].min(), df_last["Temp_cooler_output.T"].min()), 26]

y_rh_lim = [0, 100]
y_x_lim = [
    min(df_full["senMasFra_return.X"].min(), df_last["senMasFra_return.X"].min()),
    max(df_full["senMasFra_heated.X"].max(), df_last["senMasFra_heated.X"].max())
]
y_light_lim = [
    0,
    int(np.ceil(max(df_extra_full["Light_intensity_W.y"].max(), df_extra_last["Light_intensity_W.y"].max()) + 100))
]

# ───── figure setup ─────────────────────────────────────
fig, axes = plt.subplots(nrows=4, ncols=2, sharex='col', figsize=(30, 20),
                         height_ratios=[2, 1.6, 1.4, 1.2])

titles = ["First 48 Hours", "Last 48 Hours"]
ylabels = ["Temperature [°C]", "RH [%]", "Humidity Ratio [–]", "Light [W]"]
xticks = range(0, 49, 6)

# ───── plotting ─────────────────────────────────────────
for row, ylabel in enumerate(ylabels):
    for col, (df, df_extra, t) in enumerate([
        (df_full, df_extra_full, t_full),
        (df_last, df_extra_last, t_last)
    ]):
        ax = axes[row][col]

        if row == 0:
            ax.plot(t, df["Temp_heater_output.T"], label="Supply air", color="red", linewidth=4)
            ax.plot(t, df["Temp_cooler_output.T"], label="Cooled air", color="blue", linewidth=4)
            ax.plot(t, df["Temp_return_air.T"], label="Return air", color="lime", linewidth=7,
                    path_effects=[pe.Stroke(linewidth=8.5, foreground='darkgreen'), pe.Normal()])
            ax.plot(t, df["Temp_Distributer.y"], label="Set-point", color="black", linestyle="--", linewidth=4)
            ax.set_ylim(y_temp_lim)

        elif row == 1:
            ax.plot(t, df["RH_cooler_output.phi"] * 100, label="Cooled air", color="blue", linewidth=4)
            ax.plot(t, df["RH_return_air.phi"] * 100, label="Return-air", color="lime", linewidth=7,
                    path_effects=[pe.Stroke(linewidth=8.5, foreground='darkgreen'), pe.Normal()])
            ax.plot(t, df["RH_Distributer.y"] * 100, label="Set-point", color="black", linestyle="--", linewidth=4)
            ax.set_ylim(y_rh_lim)

        elif row == 2:
            ax.plot(t, df["senMasFra_return.X"], label="Return-air", color="limegreen", linewidth=4)
            ax.plot(t, df["senMasFra_heated.X"], label="Supply-air", color="red", linewidth=4)
            ax.set_ylim(y_x_lim)

        elif row == 3:
            ax.plot(t, df_extra["Light_intensity_W.y"], label="Light intensity", color="orange", linewidth=4)
            ax.set_ylim(y_light_lim)
            ax.set_yticks(np.arange(y_light_lim[0], y_light_lim[1] + 1, 200))
            ax.set_xlabel("Time [hours]", fontsize=40, labelpad=20)
            ax.set_xticks(xticks)

        ax.set_xlim(0, 48.01)
        if col == 0:
            ax.set_ylabel(ylabel, fontsize=40, labelpad=20)
        if row == 0:
            ax.set_title(titles[col], fontsize=40, pad=20)

        ax.tick_params(axis='both', labelsize=30)
        ax.grid(True)

    # shared legend (right of right-hand column)
    handles, labels = axes[row][1].get_legend_handles_labels()
    axes[row][1].legend(handles, labels, fontsize=35, loc="center left", bbox_to_anchor=(1.02, 0.5))

# ───── layout and save ──────────────────────────────────
fig.tight_layout()
fig.subplots_adjust(left=0.08, right=0.8, hspace=0.45, wspace=0.16)

outfile = plot_dir / "Plot_growth_test_600W_first_and_last_48_hours_steps.png"
fig.savefig(outfile, dpi=300)
plt.close(fig)

print(f"✔ Plot saved to: {outfile}")
