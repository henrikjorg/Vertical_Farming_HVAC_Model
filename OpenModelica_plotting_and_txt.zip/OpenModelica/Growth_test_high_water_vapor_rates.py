import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
import numpy as np
import matplotlib.patheffects as pe

# ───── paths ─────────────────────────────────────────────
CSV_PATH_CLIMATE = Path("OpenModelica/CSV_files/Growth_HVAC_tests/Growth_test_600W_double_humidity_rates.csv")
CSV_PATH_EXTRA   = Path("OpenModelica/CSV_files/Growth_HVAC_tests/Growth_test_600W_extra_double_humidity_rates.csv")
PLOT_DIR = Path("OpenModelica/plot_storage/growth_tests")
PLOT_DIR.mkdir(parents=True, exist_ok=True)

# ───── load data ─────────────────────────────────────────
df = pd.read_csv(CSV_PATH_CLIMATE)
df_extra = pd.read_csv(CSV_PATH_EXTRA)
t_d = df["time"] / 86400  # seconds → days

# ───── create stacked subplots ───────────────────────────
fig, (axT, axRH, axX, axL, axV) = plt.subplots(
    nrows=5, ncols=1, sharex=True,
    figsize=(20, 22),
    height_ratios=[2, 1.6, 1.4, 1.2, 1.4]
)

# ───── Temperature ───────────────────────────────────────
axT.plot(t_d, df["Temp_heater_output.T"],  label="Supply air", color="red", linewidth=2)
axT.plot(t_d, df["Temp_cooler_output.T"],  label="Cooled air", color="blue", linewidth=2)
axT.plot(t_d, df["Temp_return_air.T"], label="Return air", color="lime", linewidth=5,
         path_effects=[pe.Stroke(linewidth=6.5, foreground='darkgreen'), pe.Normal()])
axT.plot(t_d, df["Temp_Distributer.y"],    label="Set-point", color="black", linestyle="--", linewidth=2)
axT.set_ylabel("Temperature [°C]", fontsize=30, labelpad=15)
axT.tick_params(axis='both', labelsize=30)
axT.grid(True)
axT.legend(fontsize=30, loc="center left", bbox_to_anchor=(1.02, 0.5), borderaxespad=0)

# ───── RH (%) ────────────────────────────────────────────
axRH.plot(t_d, df["RH_cooler_output.phi"] * 100, label="Cooled air", color="blue", linewidth=2)
axRH.plot(t_d, df["RH_return_air.phi"] * 100, label="Return-air", color="lime", linewidth=5,
          path_effects=[pe.Stroke(linewidth=6.5, foreground='darkgreen'), pe.Normal()])
axRH.plot(t_d, df["RH_Distributer.y"] * 100,     label="Set-point",  color="black", linestyle="--", linewidth=2)
axRH.set_ylabel("RH [%]", fontsize=30, labelpad=15)
axRH.set_ylim(0, 100)
axRH.set_xlim(0, 24.01)
axRH.set_xticks([0, 4, 8, 12, 16, 20, 24])
axRH.tick_params(axis='both', labelsize=30)
axRH.grid(True)
axRH.legend(fontsize=30, loc="center left", bbox_to_anchor=(1.02, 0.5), borderaxespad=0)

# ───── Humidity ratio ───────────────────────────────────
axX.plot(t_d, df["senMasFra_return.X"], label="Return-air", color="limegreen", linewidth=2)
axX.plot(t_d, df["senMasFra_heated.X"], label="Supply-air", color="red", linewidth=2)
axX.set_ylabel("Humidity ratio [–]", fontsize=30, labelpad=15)
axX.set_xlim(0, 24.01)
axX.set_xticks([0, 4, 8, 12, 16, 20, 24])
axX.tick_params(axis='both', labelsize=30)
axX.grid(True)
axX.legend(fontsize=30, loc="center left", bbox_to_anchor=(1.02, 0.5), borderaxespad=0)

# ───── Light Intensity ──────────────────────────────────
axL.plot(t_d, df_extra["Light_intensity_W.y"], color="orange", linewidth=2, label="Light intensity")
axL.set_ylabel("Light [W]", fontsize=30, labelpad=15)
axL.set_yticks(range(0, int(df_extra["Light_intensity_W.y"].max()) + 100, 200))
axL.tick_params(axis='both', labelsize=30)
axL.grid(True)
axL.legend(fontsize=30, loc="center left", bbox_to_anchor=(1.02, 0.5), borderaxespad=0)

# ───── Water Vapor Rate (bottom subplot) ─────────────────
axV.plot(t_d, df_extra["gain_water_vapor.y"], label="Total rate of\nwater vapor", color="blue", linewidth=2)
axV.set_xlabel("Time [days]", fontsize=30, labelpad=15)
axV.set_ylabel("Water vapor [g/s]", fontsize=30, labelpad=15)
axV.set_xlim(0, 24.01)
axV.set_xticks([0, 4, 8, 12, 16, 20, 24])
axV.set_yticks(np.arange(0, df_extra["gain_water_vapor.y"].max() + 0.01, 0.01))  # <<< this line
axV.tick_params(axis='both', labelsize=30)
axV.grid(True)
axV.legend(fontsize=30, loc="center left", bbox_to_anchor=(1.02, 0.5), borderaxespad=0)

# ───── layout + export ──────────────────────────────────
fig.tight_layout()
fig.subplots_adjust(left=0.13, right=0.76, hspace=0.35)

outfile = PLOT_DIR / "Plot_growth_test_600W_double_humidity_rates.png"
fig.savefig(outfile, dpi=300)
plt.close(fig)

print(f"✔ Final combined plot saved to: {outfile}")
