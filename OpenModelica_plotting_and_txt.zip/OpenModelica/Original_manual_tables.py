import matplotlib.pyplot as plt
import numpy as np

# Setpoints
rh_setpoints = [50, 55, 60, 65, 70, 75, 80, 85]
temp_setpoints = [20, 21, 22, 23, 24, 25, 26, 27, 28]
w_vapor_fractions = [0.01, 0.02, 0.03]

# Cooling temperature datasets
cooling_data_300_1 = np.array([
    [11.8189, 13.7932, 15.5086, 17.0464, np.nan, np.nan, 20.88, np.nan, np.nan],
    [np.nan, np.nan, 17.3141, 18.6104, np.nan, np.nan, np.nan, 22.8, np.nan],
    [np.nan, np.nan, np.nan, 19.6628, np.nan, np.nan, np.nan, np.nan, 24.65],
    [np.nan, np.nan, np.nan, 20.2, np.nan, np.nan, np.nan, np.nan, 25.37],
    [np.nan, np.nan, np.nan, np.nan, 21.87, np.nan, np.nan, np.nan, 26.0931],
    [np.nan, np.nan, np.nan, np.nan, 22.4467, 23.46, np.nan, np.nan, 26.4701],
    [np.nan, np.nan, np.nan, np.nan, 22.7989, 23.8033, np.nan, np.nan, 26.7923],
    [np.nan, np.nan, np.nan, np.nan, 23.0985, 24.0972, np.nan, np.nan, 27.0736],
])

cooling_data_300_2 = np.array([
    [np.nan, 11.9134, 13.4866, 14.9361, 16.4947, np.nan, np.nan, np.nan, np.nan],
    [12.6344, 14.0825, 15.4301, 17.0191, 18.4966, np.nan, 21.11, np.nan, np.nan],
    [np.nan, 15.6926, 17.1774, 18.5458, 19.8309, np.nan, np.nan, 23.05, np.nan],
    [np.nan, np.nan, 18.3744, 19.5981, 20.7729, np.nan, np.nan, 23.79, np.nan],
    [np.nan, np.nan, np.nan, 20.3626, 21.472, np.nan, np.nan, np.nan, 25.7214],
    [np.nan, np.nan, np.nan, 20.9443, 22.0141, np.nan, np.nan, np.nan, 26.1664],
    [np.nan, np.nan, np.nan, np.nan, 22.4494, np.nan, np.nan, np.nan, 26.54],
    [np.nan, np.nan, np.nan, np.nan, 22.8109, np.nan, np.nan, np.nan, 26.8609],
])

cooling_data_300_3 = np.array([
    [np.nan,  np.nan, 12.2465, 13.885,   15.3826, np.nan,   np.nan,   np.nan,   np.nan],
    [11.425, 13.0334, 14.5026, 15.9268,  17.2375, 18.4841,  np.nan,   np.nan,   np.nan],
    [13.4612, 14.8667, 16.1818, 17.4283,  18.6215, 19.9577,  21.285,   np.nan,   np.nan],
    [np.nan,  16.2218, 17.4197, 18.5728,  19.8318, 21.0964,  22.3066,  23.4751,  np.nan],
    [np.nan,  np.nan, 18.3806, 19.5427,  20.7612, 21.9342,  23.0725,  24.1835,  np.nan],
    [np.nan,  np.nan, np.nan,  20.3162,  21.4614, 22.5771,  23.6697,  24.7439,  25.803],
    [np.nan,  np.nan, np.nan,  20.9109,  22.0096, 23.0885,  24.1515,  25.2014,  26.2404],
    [np.nan,  np.nan, np.nan,  21.3848,  22.4534, 23.508,   24.5512,  25.5848,  26.6102],
])

cooling_all = [cooling_data_300_1, cooling_data_300_2, cooling_data_300_3]

# Supply air temperatures
supply_air_300_2 = np.array([13.3, 15.9, 18.53, 21.13, 23.72, 26.305, 28.9, 31.47, 34.04])
supply_air_300_3 = np.array([13.72, 16.32, 18.91, 21.51, 24.1, 26.70, 29.30, 31.85, 34.42])
delta_2 = np.array(temp_setpoints) - supply_air_300_2
delta_3 = np.array(temp_setpoints) - supply_air_300_3

# Create 3x2 plot layout
fig, axs = plt.subplots(3, 2, figsize=(15, 12))

# Plot 1: 0.03 g/s
for rh, temps in zip(rh_setpoints, cooling_data_300_3):
    axs[0, 0].plot(temp_setpoints, temps, marker='o', label=f'{rh} % RH')
axs[0, 0].set_title('Cooling Temp vs T_set (300 W, 0.03 g/s)')
axs[0, 0].set_xlabel('T_set [°C]')
axs[0, 0].set_ylabel('T_cool [°C]')
axs[0, 0].grid(True)
axs[0, 0].legend(title='RH')

# Plot 2: 0.02 g/s
for i, rh in enumerate(rh_setpoints):
    temps = cooling_data_300_2[i]
    valid = ~np.isnan(temps)
    axs[0, 1].plot(np.array(temp_setpoints)[valid], temps[valid], marker='o', label=f'{rh} % RH')
axs[0, 1].set_title('Cooling Temp vs T_set (300 W, 0.02 g/s)')
axs[0, 1].set_xlabel('T_set [°C]')
axs[0, 1].set_ylabel('T_cool [°C]')
axs[0, 1].grid(True)
axs[0, 1].legend(title='RH')

# Plot 3: 0.01 g/s
for i, rh in enumerate(rh_setpoints):
    temps = cooling_data_300_1[i]
    valid = ~np.isnan(temps)
    axs[1, 0].plot(np.array(temp_setpoints)[valid], temps[valid], marker='o', label=f'{rh} % RH')
axs[1, 0].set_title('Cooling Temp vs T_set (300 W, 0.01 g/s)')
axs[1, 0].set_xlabel('T_set [°C]')
axs[1, 0].set_ylabel('T_cool [°C]')
axs[1, 0].grid(True)
axs[1, 0].legend(title='RH')

# Plot 4: T_cool vs w_vapor
complete_points = {}
for rh_idx, rh in enumerate(rh_setpoints):
    for t_idx, T in enumerate(temp_setpoints):
        vals = [data[rh_idx][t_idx] for data in cooling_all]
        if all(not np.isnan(v) for v in vals):
            complete_points[(rh, T)] = vals
for (rh, T), temps in complete_points.items():
    axs[1, 1].plot(w_vapor_fractions, temps, marker='o', label=f'{T} °C, {rh}%')
axs[1, 1].set_title('Cooling Temp vs w_vapor (Complete Points)')
axs[1, 1].set_xlabel('Water Vapor Fraction [kg/kg]')
axs[1, 1].set_ylabel('T_cool [°C]')
axs[1, 1].grid(True)
axs[1, 1].legend(title='T_set, RH', fontsize=6)

# Plot 5: ΔT = T_set - T_supply
axs[2, 0].plot(temp_setpoints, delta_3, marker='o', label='0.03 g/s')
axs[2, 0].plot(temp_setpoints, delta_2, marker='o', label='0.02 g/s')
axs[2, 0].set_title('ΔT = T_set - T_supply')
axs[2, 0].set_xlabel('T_set [°C]')
axs[2, 0].set_ylabel('ΔT [°C]')
axs[2, 0].grid(True)
axs[2, 0].legend()

# Hide unused plot
axs[2, 1].axis('off')

plt.tight_layout()
plt.show()


# Cooling data (top values from green cells, NaN for missing)
cooling_data_001 = np.array([
    [11.8189, 13.7932, 15.5086, 17.0464, 18.4586, 19.7795, 21.0326, 22.2339, 23.3951],
    [14.4022, 15.9248, 17.3141, 18.6104, 19.8397, 21.0192, 22.1609, 23.2731, 24.362],
    [15.9928, 17.2794, 18.4962, 19.6628, 20.7922, 21.8933, 22.9724, 24.0339, 25.0811],
    [17.0362, 18.1972, 19.32,   20.4145, 21.4876, 22.5438, 23.5866, 24.6183, 25.6408],
    [17.81,  18.8569, 19.9269, 20.9804, 22.0207, 23.0506, 24.0717, 25.0856, 26.0931],
    [18.3314,  19.3566, 20.3963, 21.4256, 22.4467, 23.4607, 24.4688, 25.4717, 26.4701],
    [18.7402,  19.7525, 20.7743, 21.7895, 22.7989, 23.8033, 24.8035, 25.7996, 26.7923],
    [19.0737,  20.0782, 21.0895, 22.0961, 23.0985, 24.0972, 25.094,  26.0844, 27.0736],
])

# Plotting
plt.figure(figsize=(10, 6))
for i, rh in enumerate(rh_setpoints):
    temps = cooling_data_001[i]
    mask = ~np.isnan(temps)
    plt.plot(np.array(temp_setpoints)[mask], temps[mask], marker='o', label=f'{rh} % RH')

plt.xlabel('Temperature Setpoint [°C]')
plt.ylabel('Cooling Temperature [°C]')
plt.title('Cooling Temperature vs. Setpoint (0 W, 0.01 g/s)')
plt.grid(True)
plt.legend(title='Relative Humidity')
plt.tight_layout()
plt.show()






# Existing known values for RH = 50%, T_set = 22 to 25
t_known = np.array([22, 23, 24, 25])
cooling_known = np.array([12.2465, 13.885, 15.3826, 16.7783])

# Fit linear model
coeffs = np.polyfit(t_known, cooling_known, 1)
t_missing = 20
t_cool_50_20 = np.polyval(coeffs, t_missing)
t_missing = 21
t_cool_50_21 = np.polyval(coeffs, t_missing)

print(f"Estimated T_cool for RH = 50%, T_set = 20 °C: {t_cool_50_20:.4f} °C")
print(f"Estimated T_cool for RH = 50%, T_set = 21 °C: {t_cool_50_21:.4f} °C")


cooling_data_003 = np.array([
    [t_cool_50_20,  t_cool_50_21, 12.2465, 13.885, 15.3826, 16.7783, 18.0985, 19.4315, 20.9497],
    [11.425, 13.0334, 14.5026, 15.9268, 17.2375, 18.4841, 19.8573, 21.2716, 22.5093],
    [13.4612, 14.8667, 16.1818, 17.4283, 18.6215, 19.9577, 21.285, 22.5458, 23.7556],
    [14.9656, 16.2218, 17.4197, 18.5728, 19.8318, 21.0964, 22.3066, 23.4751, 24.611],
    [16.0971, 17.2579, 18.3806, 19.5427, 20.7612, 21.9342, 23.0725, 24.1835, 25.2728],
    [16.9754, 18.075, 19.1494, 20.3162, 21.4614, 22.5771, 23.6697, 24.7439, 25.803],
    [17.6781, 18.7388, 19.786, 20.9109, 22.0096, 23.0885, 24.1515, 25.2014, 26.2404],
    [18.2572, 19.2936, 20.3182, 21.3848, 22.4534, 23.508, 24.5512, 25.5848, 26.6102],
])


# Plotting
plt.figure(figsize=(10, 6))
for i, rh in enumerate(rh_setpoints):
    temps = cooling_data_003[i]
    mask = ~np.isnan(temps)
    plt.plot(np.array(temp_setpoints)[mask], temps[mask], marker='o', label=f'{rh} % RH')

plt.xlabel('Temperature Setpoint [°C]')
plt.ylabel('Cooling Temperature [°C]')
plt.title('Cooling Temperature vs. Setpoint (0 W, 0.01 g/s)')
plt.grid(True)
plt.legend(title='Relative Humidity')
plt.tight_layout()
plt.show()
