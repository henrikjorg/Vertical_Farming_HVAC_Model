# cooling_tables.py
"""
Module to generate per-run cooling tables (CSV & color-coded PNG) from OpenModelica CSV outputs.
"""
import glob
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import rcParams

# ────────── folders ───────────────────────────────────────────
CSV_DIR  = Path("OpenModelica/CSV_files")
TEMP_DIR = Path("OpenModelica/Temporary_information")
PLOT_DIR = Path("OpenModelica/plot_storage")

TEMP_DIR.mkdir(exist_ok=True, parents=True)
PLOT_DIR.mkdir(exist_ok=True, parents=True)

# ───────── configuration ──────────────────────────────────────
PATTERN         = str(CSV_DIR / "Full_range_test_*gs_*W_*degC.csv")
T_PERIOD        = 30_000
T_SAMPLE_OFFSET = 29_999
T_TOL           = 0.05
RH_TOL          = 0.01

TEMPS  = list(range(15, 31))  # 15–30 °C
RH_SET = [0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85]

rcParams["font.size"] = 12

def build_cooling_array(df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    """Return (cool_temps, green_mask) arrays for set-point vs RH."""
    times = np.arange(T_SAMPLE_OFFSET, df.time.max() + 1, T_PERIOD)
    records = []
    for t in times:
        row = df[df.time <= t].iloc[-1]
        records.append({
            't_set':  int(round(row['Temp_Distributer.y'])),
            'rh_set': round(row['RH_Distributer.y'], 2),
            'cool':   row['Temp_cooler_output.T'],
            'ret_t':  row['Temp_return_air.T'],
            'ret_rh': row['RH_return_air.phi']
        })
    sam = pd.DataFrame(records).drop_duplicates(['t_set','rh_set'], keep='last')
    sam['green'] = (
        (sam.ret_t.sub(sam.t_set).abs() < T_TOL) &
        (sam.ret_rh.sub(sam.rh_set).abs() < RH_TOL)
    )

    cool_tbl = (
        sam
        .pivot(index='t_set', columns='rh_set', values='cool')
        .reindex(index=TEMPS, columns=RH_SET)
    )
    green_tbl = (
        sam
        .pivot(index='t_set', columns='rh_set', values='green')
        .reindex(index=TEMPS, columns=RH_SET, fill_value=False)
    )
    return cool_tbl.to_numpy(), green_tbl.to_numpy(dtype=bool)

def colour_table(ax, colours: np.ndarray, rowLabels, colLabels, fontsize=8):
    """
    Draw a table of blank text cells colored according to `colours`,
    with the given row and column labels.
    Fixed row height of 1.2.
    """
    n_rows, n_cols = colours.shape
    tbl = ax.table(
        cellText    = [[''] * n_cols for _ in range(n_rows)],
        cellColours = colours,
        rowLabels   = rowLabels,
        colLabels   = colLabels,
        cellLoc     = 'center',
        loc         = 'upper left'
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(fontsize)
    tbl.scale(1, 1.5)  # increased row height
    for cell in tbl.get_celld().values():
        cell.set_linewidth(0.5)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(left=False, labelleft=False, bottom=False, labelbottom=False)
    return tbl

def save_table_png(tbl, fig, ax, path: Path,
                   xlabel: str = None, ylabel: str = None,
                   pad: float = 0.02):
    """
    Resize the figure to fit the table bbox, add optional axis labels,
    adjust column widths (auto +0.2), and save.
    """
    if xlabel:
        ax.set_xlabel(xlabel)
        ax.xaxis.set_label_position('top')
        ax.xaxis.set_label_coords(0.5, 1.02)
    if ylabel:
        ax.set_ylabel(ylabel)
        ax.yaxis.set_label_position('left')
        ax.yaxis.set_label_coords(-0.18, 0.5)  # shifted left for padding

    # autoset column widths then offset
    cols = sorted({col for (_, col) in tbl.get_celld().keys() if col >= 0})
    tbl.auto_set_column_width(col=cols)
    for (r, c), cell in tbl.get_celld().items():
        if c >= 0:
            cell.set_width(cell.get_width() + 0.4)

    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bbox = tbl.get_window_extent(renderer).transformed(fig.dpi_scale_trans.inverted())

    artists = [tbl]
    if xlabel:
        artists.append(ax.xaxis.label)
    if ylabel:
        artists.append(ax.yaxis.label)

    fig.set_size_inches(bbox.width, bbox.height)
    fig.savefig(path, dpi=300, bbox_inches='tight', pad_inches=pad, bbox_extra_artists=artists)
    plt.close(fig)

def save_and_plot(cool_arr: np.ndarray, green_mask: np.ndarray, tag: str):
    """Save CSV and generate a colored cooling-table PNG for one run."""
    # CSV: no '%' in headers
    df = pd.DataFrame(cool_arr, index=[str(t) for t in TEMPS], columns=[str(int(r*100)) for r in RH_SET])
    df.to_csv(TEMP_DIR / f"{tag}_cooling_table.csv", float_format="%.3f")

    colours = np.where(green_mask, '#a1f974', '#ff9579')
    fig, ax = plt.subplots()
    tbl = colour_table(
        ax,
        colours,
        rowLabels=[str(t) for t in TEMPS],
        colLabels=[str(int(r*100)) for r in RH_SET]
    )
    save_table_png(
        tbl,
        fig,
        ax,
        PLOT_DIR / f"table_{tag}.png",
        xlabel="RH set-point [%]",
        ylabel="Temperature set-point [°C]"
    )


if __name__ == '__main__':
    # Process all matching CSV files
    paths = glob.glob(PATTERN)
    if not paths:
        print("❌ no CSV files found – check folder/pattern")
    else:
        for p in paths:
            tag = Path(p).stem
            df = pd.read_csv(p)
            cool, green = build_cooling_array(df)
            save_and_plot(cool, green, tag)