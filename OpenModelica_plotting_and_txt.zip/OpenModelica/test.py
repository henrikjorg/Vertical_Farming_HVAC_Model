import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import numpy as np
from pathlib import Path

# ───── paths ─────────────────────────────────────────────
base_dir = Path("OpenModelica/CSV_files/Growth_HVAC_tests")
plot_dir = Path("OpenModelica/plot_storage/growth_tests")
plot_dir.mkdir(parents=True, exist_ok=True)

# ───── load CSV ──────────────────────────────────────────
filename = "RH_spike.csv"
df = pd.read_csv(base_dir / filename)

# ───── filter time window 551–554 h ─────────────────────
start_sec = 551 * 3600
end_sec = 554 * 3600
df_window = df[(df["time"] >= start_sec) & (df["time"] <= end_sec)]
t = (df_window["time"] - df_window["time"].min()) / 3600  # Relative time [h]

# ───── figure setup ─────────────────────────────────────
fig, axes = plt.subplots(nrows=3, ncols=1, figsize=(22, 18), sharex=True)
ylabels = [
    "Temperature [°C]",
    "Relative Humidity [%]",
    "Humidity Ratio [–]"
]

# ───── temperature subplot ──────────────────────────────
ax = axes[0]
ax.plot(t, df_window["Temp_return_air.T"], label="Return air", color="lime", linewidth=6,
        path_effects=[pe.Stroke(linewidth=8, foreground='darkgreen'), pe.Normal()])
ax.plot(t, df_window["Temp_Distributer.y"], label="Set-point", color="black", linestyle="--", linewidth=3)
ax.plot(t, df_window["Temp_cooler_output.T"], label="Cooler output", color="deepskyblue", linewidth=4)
ax.set_ylabel(ylabels[0], fontsize=34, labelpad=20)
ax.legend(fontsize=28, loc="best")
ax.grid(True)

# ───── RH subplot ───────────────────────────────────────
ax = axes[1]
ax.plot(t, df_window["RH_return_air.phi"] * 100, label="Return air", color="lime", linewidth=6,
        path_effects=[pe.Stroke(linewidth=8, foreground='darkgreen'), pe.Normal()])
ax.plot(t, df_window["RH_Distributer.y"] * 100, label="Set-point", color="black", linestyle="--", linewidth=3)
ax.set_ylabel(ylabels[1], fontsize=34, labelpad=20)
ax.legend(fontsize=28, loc="best")
ax.grid(True)

# ───── Humidity Ratio subplot ───────────────────────────
ax = axes[2]
ax.plot(t, df_window["senMasFra_return.X"], label="Return air", color="lime", linewidth=6,
        path_effects=[pe.Stroke(linewidth=8, foreground='darkgreen'), pe.Normal()])
ax.plot(t, df_window["x_pTphi.X[1]"], label="Calculated Set-point", color="black", linestyle="--", linewidth=3)
ax.set_ylabel(ylabels[2], fontsize=34, labelpad=20)
ax.set_xlabel("Time [hours]", fontsize=34, labelpad=20)
ax.legend(fontsize=28, loc="best")
ax.grid(True)

# ───── layout and save ──────────────────────────────────
for ax in axes:
    ax.tick_params(axis='both', labelsize=26, pad=10)
    ax.set_xlim(0, t.max())
axes[2].set_xticks(np.arange(0, t.max() + 0.5, 0.5))

fig.tight_layout(pad=5.0)
outfile = plot_dir / "Plot_growth_23_to_26_hours.png"
fig.savefig(outfile, dpi=300)
plt.close(fig)

print(f"✔ Plot saved to: {outfile}")
